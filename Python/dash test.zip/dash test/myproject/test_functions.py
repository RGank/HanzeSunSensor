import random

def update_temp(temperature):
    temperature = round(random.randint(0, 3000)/100, 1)
